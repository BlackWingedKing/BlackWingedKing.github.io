from algorithms import matrix, matrix_gpu, random_walk, rectangle, square_exit
from algorithms.rectangle import RectangleCache
from algorithms.square_exit import SquareExitCache


__enum Algorithm(ImplicitlyCopyable):
    case random_walk
    case square_exit
    case matrix
    case matrix_gpu
    case rectangle


struct Grid[num_cols: Int, num_rows: Int]:
    var cells: List[Int]  # Holds the current generation
    var count: Int
    var current_particle_pos: Optional[Tuple[Int, Int]]
    var _rectangle: RectangleCache
    var _square_exit: SquareExitCache

    def __init__(out self):
        comptime assert Self.num_cols > 1 and Self.num_rows > 1
        self.count = Self.num_cols * Self.num_rows
        self.cells = List[Int](length=self.count, fill=0)
        self.current_particle_pos = None
        self._rectangle = RectangleCache()
        self._square_exit = SquareExitCache()

        # set the center particle to 1
        self[(Self.num_cols // 2, Self.num_rows // 2)] = 1

    comptime to_index = lambda (x: Int, y: Int) -> Int: (y * Self.num_cols + x)

    comptime to_coord = lambda (i: Int) -> Tuple[Int, Int]: (
        (i % Self.num_cols, i // Self.num_cols)
    )

    def print_grid(self):
        var grid_str = ""
        var particle_index = -1
        if self.current_particle_pos:
            var pos = self.current_particle_pos.value()
            particle_index = Self.to_index(pos[0], pos[1])
        for index in range(len(self.cells)):
            if index == particle_index:
                grid_str += "@"
            else:
                grid_str += "X" if self.cells[index] else "."
            if (
                index % Self.num_cols == (Self.num_cols - 1)
                and index != len(self.cells) - 1
            ):
                grid_str += "\n"
        print(grid_str)

    def __setitem__(mut self, coord: Tuple[Int, Int], value: Int):
        if not self.is_valid_coord(coord):
            return  # no op
        var index = Self.to_index(coord[0], coord[1])
        if len(self._square_exit.distances) != 0:
            if value != 0:
                self._square_exit.add_particle[Self.num_cols, Self.num_rows](
                    index
                )
            elif self.cells[index] != 0:
                self._square_exit.invalidate()
        self.cells[index] = value

    def __getitem__(self, coord: Tuple[Int, Int]) -> Int:
        return self.cells[Self.to_index(coord[0], coord[1])]

    def is_valid_coord(self, coord: Tuple[Int, Int]) -> Bool:
        return not (
            coord[0] < 0
            or coord[0] >= Self.num_cols
            or coord[1] < 0
            or coord[1] >= Self.num_rows
        )

    @staticmethod
    def _boundary_coord(index: Int) -> Tuple[Int, Int]:
        if index < Self.num_cols:
            return (index, 0)
        if index < 2 * Self.num_cols:
            return (index - Self.num_cols, Self.num_rows - 1)
        var side_index = index - 2 * Self.num_cols
        return (
            0 if side_index % 2 == 0 else Self.num_cols - 1,
            side_index // 2 + 1,
        )

    @staticmethod
    def neighbors(index: Int) -> Tuple[Int, Int, Int, Int]:
        var x = index % Self.num_cols
        var y = index // Self.num_cols
        return (
            index - 1 if x > 0 else -1,
            index + 1 if x + 1 < Self.num_cols else -1,
            index - Self.num_cols if y > 0 else -1,
            index + Self.num_cols if y + 1 < Self.num_rows else -1,
        )

    def _touches_cluster(self, coord: Tuple[Int, Int]) -> Bool:
        var x = coord[0]
        var y = coord[1]
        return (
            (x > 0 and self[(x - 1, y)] != 0)
            or (x < Self.num_cols - 1 and self[(x + 1, y)] != 0)
            or (y > 0 and self[(x, y - 1)] != 0)
            or (y < Self.num_rows - 1 and self[(x, y + 1)] != 0)
        )

    def spawn_and_stick_particle(
        mut self,
        *,
        algorithm: Algorithm = .random_walk,
        stickiness: Float64 = 1.0,
    ) raises -> Optional[Tuple[Int, Int]]:
        """Returns the sticking coordinate, or None if no particle can spawn."""
        random_walk._validate_stickiness(stickiness)
        if stickiness < 1:
            match algorithm:
                case .matrix | .matrix_gpu | .rectangle:
                    raise Error(
                        "stickiness below 1 requires random_walk or square_exit"
                    )
                case _:
                    pass
        match algorithm:
            case .random_walk:
                return random_walk.spawn_and_stick(self, stickiness=stickiness)
            case .square_exit:
                return square_exit.spawn_and_stick(self, stickiness=stickiness)
            case .matrix:
                return matrix.spawn_and_stick(self)
            case .matrix_gpu:
                return matrix_gpu.spawn_and_stick(self)
            case .rectangle:
                return rectangle.spawn_and_stick(self)

    def spawn_particle(mut self):
        random_walk.spawn_particle(self)

    def walk_particle(
        mut self, *, stickiness: Float64 = 1.0
    ) raises -> Optional[Tuple[Int, Int]]:
        random_walk._validate_stickiness(stickiness)
        return random_walk.walk_particle(self, stickiness=stickiness)
