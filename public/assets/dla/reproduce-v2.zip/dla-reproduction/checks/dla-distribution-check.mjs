import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
const source = readFileSync(new URL('../figures/figures.js', import.meta.url), 'utf8');
let Widget;
class Element {
  nodes = new Map();
  querySelector(selector) {
    if (!this.nodes.has(selector)) this.nodes.set(selector, {});
    return this.nodes.get(selector);
  }
}
const context = vm.createContext({ HTMLElement: Element, console, customElements: {
  get: () => false,
  define: (name, component) => { if (name === 'dla-probabilities') Widget = component; },
}});
vm.runInContext(source, context);
const solve = vm.runInContext('attachmentDistribution', context);
const fixture = JSON.parse(readFileSync(new URL('../figures/probability-figure.json', import.meta.url)));
const sites = solve(fixture.size, new Set(fixture.occupied.map(p => p.join(','))));
for (const expected of fixture.sites) {
  const actual = sites.find(s => s.x === expected.x && s.y === expected.y);
  assert.ok(actual && Math.abs(actual.mass - expected.probability) < 1e-11);
}
assert.equal(sites.length, fixture.sites.length);
const symmetric = solve(13, new Set(['6,6']));
assert.equal(symmetric.length, 4);
assert.ok(symmetric.every(s => Math.abs(s.mass - 0.25) < 1e-11));
// With every free cell at contact, all mass comes directly from launch cells.
const direct = solve(3, new Set(['1,0','0,1','2,1','1,2']));
assert.equal(direct.find(s => s.x === 1 && s.y === 1).mass, 0);
assert.ok(direct.filter(s => s.x !== 1 || s.y !== 1).every(s => s.mass === 0.25));
// A closed ring contains both unreachable sticking cells and a wandering pocket.
const ring = new Set();
for (let y=2;y<=6;y++) for (let x=2;x<=6;x++)
  if (x===2 || y===2 || x===6 || y===6) ring.add(`${x},${y}`);
const enclosed = solve(9, ring);
assert.ok(enclosed.filter(s=>s.x>2 && s.x<6 && s.y>2 && s.y<6).every(s=>s.mass===0));
assert.ok(Math.abs(enclosed.reduce((sum,s)=>sum+s.mass,0)-1)<1e-11);
// Exercise actual button handlers through growth, including occupied launch cells.
const widget = new Widget();
widget.connectedCallback();
let lastSignature = JSON.stringify(widget.sites);
for (let i=0;i<widget.size**2 && widget.sites.length;i++) {
  const old = new Set(widget.occupied);
  widget.querySelector('[data-sample]').onclick();
  assert.equal(widget.occupied.size, old.size+1);
  const [x,y] = widget.last;
  assert.ok(!old.has(`${x},${y}`));
  assert.ok([[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>old.has(`${x+dx},${y+dy}`)));
  for (const s of widget.sites) {
    assert.ok(!widget.occupied.has(`${s.x},${s.y}`));
    assert.ok(s.mass>=0 && Number.isFinite(s.mass));
  }
  assert.notEqual(JSON.stringify(widget.sites),lastSignature);
  lastSignature=JSON.stringify(widget.sites);
}
assert.equal(widget.sites.length,0);
assert.equal(widget.querySelector('[data-sample]').disabled,true);
const terminalSize=widget.occupied.size;
widget.sample();
assert.equal(widget.occupied.size,terminalSize);
widget.querySelector('[data-reset]').onclick();
assert.equal(widget.occupied.size,1);
assert.equal(widget.sites.length,4);
assert.equal(widget.querySelector('[data-sample]').disabled,false);
console.log('Distribution fixture, symmetry, direct launch, sealed pocket, growth, exhaustion and reset checks passed');
