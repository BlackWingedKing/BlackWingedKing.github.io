# My experiments with growing a fractal — evidence and reproduction

This archive contains the exact simulation sources and recorded events behind the draft article. It is prepared for macOS on Apple silicon; the GPU path requires working Apple Metal tooling. Both videos are 1× replays of separately measured runs, not simultaneous simulations or live recordings. Results depend on hardware, compiler, growth stage, and implementation.

## Setup

From this extracted directory, install Python 3.12+, uv, full Xcode and ffmpeg using their normal vendor/package-manager instructions. Select full Xcode as your developer directory. If `xcrun metal --version` reports a missing compiler component, run `xcodebuild -downloadComponent MetalToolchain`. The recorded machine used Apple M3 Pro / 36 GB, macOS and compiler versions are in each manifest. Requirements pin MAX 26.7.0 (Mojo 1.2.0).

```sh
uv venv .venv
uv pip install --python .venv/bin/python -r requirements.txt
uv pip install --python .venv/bin/python Pillow
.venv/bin/mojo --version
xcrun metal --version
.venv/bin/mojo run -I . algorithms/gpu_solver.mojo
```

## Replay the existing evidence (no simulation required)

Put ffmpeg on PATH. Renderers use the Arial fonts shipped with macOS.

```sh
.venv/bin/python research/render_methods.py --output output/five-methods
.venv/bin/python research/render_blog_video.py --output output/large-grid
.venv/bin/python research/figure_data.py output/probability-figure.json
```

Both videos loop the first eight seconds of measured computation at 1× speed, with no opening/ending holds or end card. They intentionally stop before every method finishes. The five-method clip shows the entire 101 × 101 lattice, 200-particle target, seed 42. The larger-grid clip shows a fixed 251 × 251 crop of a 501 × 501 lattice, 2,000-particle target, seed 42; the renderer checks that every recorded attachment remains in the crop. Finished panels freeze until the loop restarts. Full-run completion times remain in the benchmark manifests and article table. Neither panel is independently retimed.

## Make new measurements

Keep the bundled evidence unchanged; write fresh results to new directories. The first command compiles all five methods. Each runner executes sequentially, rotates method order across five seeds (42–46), validates the attachment events and records machine/compiler metadata. Avoid other heavy work while measuring.

```sh
.venv/bin/mojo build -O3 -I . research/method_benchmark.mojo -o /tmp/dla-method-benchmark
.venv/bin/python research/run_method_benchmark.py --binary /tmp/dla-method-benchmark --output research/new-method-results
.venv/bin/python research/render_methods.py --results research/new-method-results --output output/new-five-methods

.venv/bin/python research/run_blog_benchmark.py --output research/new-blog-results
.venv/bin/python research/render_blog_video.py --results research/new-blog-results --output output/new-large-grid
```

The larger-grid runner preserves the original experiment's CPU-only build procedure: it copies sources into a temporary directory, removes only the unused GPU import/dispatch there, compiles the two CPU methods and runs capture-on and capture-off trials. The original machine lacked the Metal compiler component at that point. The component was installed before the five-method experiment, whose build uses unmodified simulation sources. No repository source is patched by either runner.

Times sum the public spawn-and-stick calls. They include cache preparation/updates and, for GPU, context, buffers, transfers, kernel setup and CPU refinement. Ahead-of-time compilation, initial grid allocation, event storage/export and rendering are excluded. `loop_ns` includes timer/capture overhead; `process_seconds` also includes process startup/output. Each measured run is a new process and grid; there is no in-process warmup. Stickiness is 1.0 throughout.

The 101 × 101 / 200-particle workload was fixed after a separate seed-2026, 20-particle feasibility pilot. The 501 × 501 / 2,000-particle workload is a different experiment, only comparing the two walk methods. Never merge their timing rankings. A fixed seed does not produce the same cluster across methods because random numbers are consumed differently. Source SHA-256 fingerprints are included in both manifests; current runner and renderer portability changes do not alter the recorded simulation sources.

## Interactive attachment distribution

The article's 13×13 browser demo recalculates the attachment distribution after every sampled particle. Open `figures/index.html` in a browser to use the standalone demo. `figures/figures.js` contains the small dense absorbing-chain solve, including blocked-step self-loops, direct launches at contact, and exclusion of unreachable pockets. The production Mojo matrix algorithm uses its sparse solver; this small browser demo is an explanatory implementation.

`research/figure_data.py` and `figures/probability-figure.json` preserve the original independently solved 9×9 example as a validation fixture. `research/method-results/figure-validation.json` records its comparison with the actual Mojo matrix method. The browser solver is checked against that fixture, plus symmetry, sealed pockets, direct launch, repeated growth, boundary exhaustion and reset in `checks/dla-distribution-check.mjs`. Run `node checks/dla-distribution-check.mjs` from the extracted root. This validates the small illustration; the benchmark measurements are unchanged.
