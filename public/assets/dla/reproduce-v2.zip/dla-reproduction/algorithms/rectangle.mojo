"""Cache the empty exterior and solve only the rectangle around the cluster."""

from grid import Grid
from algorithms.linear_solver import solve_matrix
from algorithms.matrix import (
    inside_rectangle,
    solve_attachment_probabilities,
    stick_from_probabilities,
)


struct RectangleCache:
    var bounds: Tuple[Int, Int, Int, Int]
    var interface: List[Int]
    var correction: List[Float64]
    var source: List[Float64]

    def __init__(out self):
        self.bounds = (0, 0, -1, -1)
        self.interface = List[Int]()
        self.correction = List[Float64]()
        self.source = List[Float64]()


def _prepare_rectangle[
    num_cols: Int, num_rows: Int
](mut grid: Grid[num_cols, num_rows]) raises:
    var min_x = num_cols
    var min_y = num_rows
    var max_x = -1
    var max_y = -1
    for index in range(grid.count):
        if grid.cells[index] != 0:
            var coord = Grid[num_cols, num_rows].to_coord(index)
            min_x = min(min_x, coord[0])
            min_y = min(min_y, coord[1])
            max_x = max(max_x, coord[0])
            max_y = max(max_y, coord[1])
    if max_x < 0:
        raise Error("Rectangle method requires an occupied seed")

    # One layer for attachment sites, then an empty interface layer.
    min_x = max(0, min_x - 2)
    min_y = max(0, min_y - 2)
    max_x = min(num_cols - 1, max_x + 2)
    max_y = min(num_rows - 1, max_y + 2)
    var old = grid._rectangle.bounds
    if (
        old[0] <= min_x
        and old[1] <= min_y
        and old[2] >= max_x
        and old[3] >= max_y
    ):
        return

    # Geometric growth amortizes exterior preparation across multiple particles.
    var width = max(7, max(max_x - min_x + 3, 2 * (old[2] - old[0] + 1)))
    var height = max(7, max(max_y - min_y + 3, 2 * (old[3] - old[1] + 1)))
    width = min(num_cols, width)
    height = min(num_rows, height)
    var left = max(0, min(num_cols - width, (min_x + max_x + 1 - width) // 2))
    var top = max(0, min(num_rows - height, (min_y + max_y + 1 - height) // 2))
    _cache_rectangle_exterior(
        grid, (left, top, left + width - 1, top + height - 1)
    )


def _cache_rectangle_exterior[
    num_cols: Int, num_rows: Int
](mut grid: Grid[num_cols, num_rows], bounds: Tuple[Int, Int, Int, Int]) raises:
    """Eliminate the empty exterior, caching its Schur correction and source."""
    var exterior = List[Int]()
    var local_index = List[Int](length=grid.count, fill=-1)
    for index in range(grid.count):
        if not inside_rectangle[num_cols](index, bounds):
            local_index[index] = len(exterior)
            exterior.append(index)
    var size = len(exterior)
    var diagonal = List[Float64](length=size, fill=0.0)
    var neighbors = List[Int](length=4 * size, fill=-1)
    var source = List[Float64](length=size, fill=0.0)
    var exterior_starts = 0
    for i in range(size):
        var index = exterior[i]
        var x = index % num_cols
        var y = index // num_cols
        if x == 0 or y == 0 or x == num_cols - 1 or y == num_rows - 1:
            source[i] = 1.0
            exterior_starts += 1
        var adjacent = Grid[num_cols, num_rows].neighbors(index)
        comptime for direction in range(4):
            var neighbor = adjacent[direction]
            if neighbor >= 0:
                diagonal[i] += 1.0
                neighbors[4 * i + direction] = local_index[neighbor]

    var interface = List[Int]()
    var exterior_degree = List[Float64]()
    for y in range(bounds[1], bounds[3] + 1):
        for x in range(bounds[0], bounds[2] + 1):
            var index = Grid[num_cols, num_rows].to_index(x, y)
            var degree = Float64(0)
            var adjacent = Grid[num_cols, num_rows].neighbors(index)
            comptime for direction in range(4):
                var neighbor = adjacent[direction]
                if neighbor >= 0 and local_index[neighbor] >= 0:
                    degree += 1.0
            if degree > 0:
                interface.append(index)
                exterior_degree.append(degree)

    var boundary_size = len(interface)
    var correction = List[Float64](
        length=boundary_size * boundary_size, fill=0.0
    )
    var entry = List[Float64](length=boundary_size, fill=0.0)
    if size > 0:
        var incoming = solve_matrix(diagonal, neighbors, source)
        for i in range(boundary_size):
            var adjacent = Grid[num_cols, num_rows].neighbors(interface[i])
            comptime for direction in range(4):
                var neighbor = adjacent[direction]
                if neighbor >= 0 and local_index[neighbor] >= 0:
                    entry[i] += incoming[local_index[neighbor]]

        for j in range(boundary_size):
            var impulse = List[Float64](length=size, fill=0.0)
            var adjacent = Grid[num_cols, num_rows].neighbors(interface[j])
            comptime for direction in range(4):
                var neighbor = adjacent[direction]
                if neighbor >= 0 and local_index[neighbor] >= 0:
                    impulse[local_index[neighbor]] += 1.0
            var response = solve_matrix(diagonal, neighbors, impulse)
            for i in range(boundary_size):
                var adjacent_i = Grid[num_cols, num_rows].neighbors(
                    interface[i]
                )
                comptime for direction in range(4):
                    var neighbor = adjacent_i[direction]
                    if neighbor >= 0 and local_index[neighbor] >= 0:
                        correction[i * boundary_size + j] += response[
                            local_index[neighbor]
                        ]

        # Restore symmetry and conservation up to floating-point solve error.
        for i in range(boundary_size):
            for j in range(i + 1, boundary_size):
                var value = (
                    correction[i * boundary_size + j]
                    + correction[j * boundary_size + i]
                ) * 0.5
                if not value >= -1e-10:
                    raise Error("Invalid rectangle exterior return weight")
                value = max(value, Float64(0))
                correction[i * boundary_size + j] = value
                correction[j * boundary_size + i] = value
            var off_diagonal = Float64(0)
            for j in range(boundary_size):
                if i != j:
                    off_diagonal += correction[i * boundary_size + j]
            correction[i * boundary_size + i] = (
                exterior_degree[i] - off_diagonal
            )

        var total = Float64(0)
        for value in entry:
            if not value >= 0:
                raise Error("Invalid rectangle exterior entry weight")
            total += value
        if not abs(total - Float64(exterior_starts)) <= 1e-7 * Float64(
            exterior_starts
        ):
            raise Error(
                "Rectangle exterior entry weights lost probability mass"
            )
        for i in range(boundary_size):
            entry[i] *= Float64(exterior_starts) / total

    grid._rectangle.bounds = bounds
    grid._rectangle.interface = interface^
    grid._rectangle.correction = correction^
    grid._rectangle.source = entry^


def attachment_probabilities[
    num_cols: Int, num_rows: Int
](mut grid: Grid[num_cols, num_rows]) raises -> List[Float64]:
    _prepare_rectangle(grid)
    return solve_attachment_probabilities(
        grid,
        grid._rectangle.bounds,
        grid._rectangle.interface,
        grid._rectangle.correction,
        grid._rectangle.source,
    )


def spawn_and_stick[
    num_cols: Int, num_rows: Int
](mut grid: Grid[num_cols, num_rows]) raises -> Optional[Tuple[Int, Int]]:
    grid.current_particle_pos = None
    var probabilities = attachment_probabilities(grid)
    return stick_from_probabilities(grid, probabilities)
