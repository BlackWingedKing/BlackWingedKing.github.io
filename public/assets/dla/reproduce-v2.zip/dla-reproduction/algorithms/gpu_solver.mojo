"""Metal-compatible FP32 conjugate gradients with FP64 iterative refinement."""

from std.math import ceildiv
from std.sys import has_accelerator
from max.gpu import block_idx, global_idx, thread_idx
from max.gpu.host import DeviceContext
from max.gpu.primitives import block
from layout import ImmTileTensor, MutTileTensor, TileTensor, row_major
from algorithms.linear_solver import _apply_matrix

comptime BLOCK = 256
comptime CHECK_INTERVAL = 32
comptime MAX_REFINEMENTS = 12
# State rows: solution, residual, search direction, matrix product, diagonal.
comptime State[n: Int] = MutTileTensor[
    .float32, type_of(row_major[5, n]()), MutUntrackedOrigin
]
comptime Neighbors[n: Int] = ImmTileTensor[
    .int32, type_of(row_major[n, 4]()), ImmUntrackedOrigin
]
comptime Partials[n: Int] = MutTileTensor[
    .float32, type_of(row_major[2, ceildiv(n, BLOCK)]()), MutUntrackedOrigin
]
comptime Scalars = MutTileTensor[
    .float32, type_of(row_major[6]()), MutUntrackedOrigin
]
# Scalars: rho, alpha, beta, residual norm squared, status, target norm squared.
# Status is 1 while solving, 0 when converged, and -1 on numerical breakdown.


def _initialize[n: Int](state: State[n], partials: Partials[n], size: Int32):
    comptime assert state.flat_rank == 2
    comptime assert partials.flat_rank == 2
    var i = global_idx.x
    var rho = Float32(0)
    var norm = Float32(0)
    if i < Int(size):
        var residual = state[1, i]
        state[0, i] = 0
        state[2, i] = residual / state[4, i]
        rho = residual * state[2, i]
        norm = residual * residual
    var rho_sum = block.sum[block_size=BLOCK](rho)
    var norm_sum = block.sum[block_size=BLOCK](norm)
    if thread_idx.x == 0:
        partials[0, block_idx.x] = rho_sum
        partials[1, block_idx.x] = norm_sum


def _reduce[
    n: Int
](partials: Partials[n], scalars: Scalars, groups: Int32, stage: Int32):
    comptime assert partials.flat_rank == 2
    comptime assert scalars.flat_rank == 1
    if stage != 0 and scalars[4] != 1:
        return
    var rho = Float32(0)
    var norm = Float32(0)
    for i in range(thread_idx.x, Int(groups), BLOCK):
        rho += partials[0, i]
        norm += partials[1, i]
    var total_rho = block.sum[block_size=BLOCK](rho)
    var total_norm = block.sum[block_size=BLOCK](norm)
    if thread_idx.x == 0:
        if stage == 0:
            scalars[0] = total_rho
            scalars[3] = total_norm
            scalars[4] = 1 if total_norm > 0 else 0
            scalars[5] = total_norm * 1e-6  # Inner relative tolerance: 1e-3.
        elif stage == 1:
            if not total_rho > 0:
                scalars[4] = -1
                return
            scalars[1] = scalars[0] / total_rho
        else:
            scalars[2] = total_rho / scalars[0]
            scalars[0] = total_rho
            scalars[3] = total_norm
            if not total_norm >= 0:
                scalars[4] = -1
            elif total_norm <= scalars[5]:
                scalars[4] = 0


def _multiply[
    n: Int
](
    state: State[n],
    neighbors: Neighbors[n],
    partials: Partials[n],
    scalars: Scalars,
    size: Int32,
):
    comptime assert state.flat_rank == 2
    comptime assert neighbors.flat_rank == 2
    comptime assert partials.flat_rank == 2
    comptime assert scalars.flat_rank == 1
    if scalars[4] != 1:
        return
    var i = global_idx.x
    var dot = Float32(0)
    if i < Int(size):
        var value = state[4, i] * state[2, i]
        comptime for direction in range(4):
            var neighbor = Int(neighbors[i, direction])
            if neighbor >= 0:
                value -= state[2, neighbor]
        state[3, i] = value
        dot = state[2, i] * value
    var total = block.sum[block_size=BLOCK](dot)
    if thread_idx.x == 0:
        partials[0, block_idx.x] = total


def _update[
    n: Int
](state: State[n], partials: Partials[n], scalars: Scalars, size: Int32,):
    comptime assert state.flat_rank == 2
    comptime assert partials.flat_rank == 2
    comptime assert scalars.flat_rank == 1
    if scalars[4] != 1:
        return
    var i = global_idx.x
    var rho = Float32(0)
    var norm = Float32(0)
    if i < Int(size):
        state[0, i] += scalars[1] * state[2, i]
        var residual = state[1, i] - scalars[1] * state[3, i]
        state[1, i] = residual
        rho = residual * residual / state[4, i]
        norm = residual * residual
    var rho_sum = block.sum[block_size=BLOCK](rho)
    var norm_sum = block.sum[block_size=BLOCK](norm)
    if thread_idx.x == 0:
        partials[0, block_idx.x] = rho_sum
        partials[1, block_idx.x] = norm_sum


def _direction[n: Int](state: State[n], scalars: Scalars, size: Int32):
    comptime assert state.flat_rank == 2
    comptime assert scalars.flat_rank == 1
    var i = global_idx.x
    if scalars[4] == 1 and i < Int(size):
        state[2, i] = state[1, i] / state[4, i] + scalars[2] * state[2, i]


def _solve_on_gpu[
    capacity: Int
](
    diagonal: List[Float64],
    neighbors: List[Int],
    source: List[Float64],
) raises -> List[Float64]:
    """Meet the CPU solver's 1e-10 relative residual using GPU corrections."""
    var size = len(source)
    var field = List[Float64](length=size, fill=0.0)
    var source_norm = Float64(0)
    for value in source:
        source_norm += value * value
    if size == 0 or source_norm == 0:
        return field^
    if size > capacity or capacity > 2147483647:
        raise Error("GPU matrix dimensions exceed buffer capacity")
    for value in diagonal:
        if not value > 0:
            raise Error("Matrix diagonal must be positive")

    var ctx = DeviceContext()
    var state_buffer = ctx.enqueue_create_buffer[.float32](5 * capacity)
    var neighbor_buffer = ctx.enqueue_create_buffer[.int32](4 * capacity)
    comptime max_groups = ceildiv(capacity, BLOCK)
    var partial_buffer = ctx.enqueue_create_buffer[.float32](2 * max_groups)
    var scalar_buffer = ctx.enqueue_create_buffer[.float32](6)
    var state = TileTensor(state_buffer, row_major[5, capacity]())
    var edges = ImmTileTensor(neighbor_buffer, row_major[capacity, 4]())
    var partials = TileTensor(partial_buffer, row_major[2, max_groups]())
    var scalars = TileTensor(scalar_buffer, row_major[6]())
    var groups = ceildiv(size, BLOCK)
    with state_buffer.map_to_host() as mapped:
        for i in range(size):
            mapped[4 * capacity + i] = Float32(diagonal[i])
    with neighbor_buffer.map_to_host() as mapped:
        for i in range(4 * size):
            mapped[i] = Int32(neighbors[i])

    var residual = source.copy()
    var product = List[Float64](length=size, fill=0.0)
    var target = source_norm * 1e-20
    for _ in range(MAX_REFINEMENTS):
        var scale = Float64(0)
        for value in residual:
            scale = max(scale, abs(value))
        # Normalize corrections so tiny FP64 residuals remain representable in FP32.
        with state_buffer.map_to_host() as mapped:
            for i in range(size):
                mapped[capacity + i] = Float32(residual[i] / scale)
        ctx.enqueue_function[_initialize[capacity]](
            state,
            partials,
            Int32(size),
            grid_dim=groups,
            block_dim=BLOCK,
        )
        ctx.enqueue_function[_reduce[capacity]](
            partials,
            scalars,
            Int32(groups),
            Int32(0),
            grid_dim=1,
            block_dim=BLOCK,
        )
        var converged = False
        for batch in range(ceildiv(2 * size, CHECK_INTERVAL)):
            for _ in range(
                min(CHECK_INTERVAL, 2 * size - batch * CHECK_INTERVAL)
            ):
                ctx.enqueue_function[_multiply[capacity]](
                    state,
                    edges,
                    partials,
                    scalars,
                    Int32(size),
                    grid_dim=groups,
                    block_dim=BLOCK,
                )
                ctx.enqueue_function[_reduce[capacity]](
                    partials,
                    scalars,
                    Int32(groups),
                    Int32(1),
                    grid_dim=1,
                    block_dim=BLOCK,
                )
                ctx.enqueue_function[_update[capacity]](
                    state,
                    partials,
                    scalars,
                    Int32(size),
                    grid_dim=groups,
                    block_dim=BLOCK,
                )
                ctx.enqueue_function[_reduce[capacity]](
                    partials,
                    scalars,
                    Int32(groups),
                    Int32(2),
                    grid_dim=1,
                    block_dim=BLOCK,
                )
                ctx.enqueue_function[_direction[capacity]](
                    state,
                    scalars,
                    Int32(size),
                    grid_dim=groups,
                    block_dim=BLOCK,
                )
            with scalar_buffer.map_to_host() as mapped:
                if mapped[4] < 0:
                    raise Error(
                        "GPU conjugate gradients lost positive definiteness"
                    )
                converged = mapped[4] == 0
            if converged:
                break
        if not converged:
            raise Error("GPU conjugate gradients did not converge")
        with state_buffer.map_to_host() as mapped:
            for i in range(size):
                field[i] += Float64(mapped[i]) * scale
        _apply_matrix(diagonal, neighbors, field, product)
        var norm = Float64(0)
        for i in range(size):
            residual[i] = source[i] - product[i]
            norm += residual[i] * residual[i]
        if norm <= target:
            return field^
    raise Error(
        "GPU iterative refinement did not meet the FP64 residual tolerance"
    )


def solve_matrix_gpu[
    capacity: Int
](
    diagonal: List[Float64],
    neighbors: List[Int],
    source: List[Float64],
) raises -> List[Float64]:
    comptime if not has_accelerator():
        raise Error(
            "matrix_gpu requires a supported GPU and the MAX accelerator"
            " library"
        )
    else:
        return _solve_on_gpu[capacity](diagonal, neighbors, source)


def main() raises:
    """Run a small GPU solve without starting the visualization."""
    var diagonal: List[Float64] = [2, 2, 2]
    var neighbors: List[Int] = [1, -1, -1, -1, 0, 2, -1, -1, 1, -1, -1, -1]
    var source: List[Float64] = [1, 0, 1]
    var field = solve_matrix_gpu[257](diagonal, neighbors, source)
    for value in field:
        if not abs(value - 1) < 1e-9:
            raise Error("GPU solver check failed")
    print("GPU solver check passed on", DeviceContext().name())
