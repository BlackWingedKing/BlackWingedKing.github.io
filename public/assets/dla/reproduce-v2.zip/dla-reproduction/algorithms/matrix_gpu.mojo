"""Full-grid matrix probabilities using GPU CG and CPU FP64 refinement."""

from grid import Grid
from algorithms import matrix


def attachment_probabilities[
    num_cols: Int, num_rows: Int
](grid: Grid[num_cols, num_rows]) raises -> List[Float64]:
    return matrix.attachment_probabilities[use_gpu=True](grid)


def spawn_and_stick[
    num_cols: Int, num_rows: Int
](mut grid: Grid[num_cols, num_rows]) raises -> Optional[Tuple[Int, Int]]:
    grid.current_particle_pos = None
    var probabilities = attachment_probabilities(grid)
    return matrix.stick_from_probabilities(grid, probabilities)
