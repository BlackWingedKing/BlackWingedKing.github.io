"""CPU conjugate-gradient solver shared by matrix and rectangle methods."""


def _apply_matrix(
    diagonal: List[Float64],
    neighbors: List[Int],
    values: List[Float64],
    mut result: List[Float64],
    boundary: List[Int] = [],
    correction: List[Float64] = [],
):
    for i in range(len(diagonal)):
        var value = diagonal[i] * values[i]
        for direction in range(4):
            var neighbor = neighbors[4 * i + direction]
            if neighbor >= 0:
                value -= values[neighbor]
        result[i] = value
    var width = len(boundary)
    for i in range(width):
        var value = Float64(0)
        for j in range(width):
            value += correction[i * width + j] * values[boundary[j]]
        result[boundary[i]] -= value


def solve_matrix(
    diagonal: List[Float64],
    neighbors: List[Int],
    source: List[Float64],
    boundary: List[Int] = [],
    correction: List[Float64] = [],
) raises -> List[Float64]:
    """Solve A phi = source with diagonally preconditioned conjugate gradients.
    """
    var size = len(source)
    var field = List[Float64](length=size, fill=0.0)
    if size == 0:
        return field^

    var preconditioner = diagonal.copy()
    for i in range(len(boundary)):
        preconditioner[boundary[i]] -= correction[i * len(boundary) + i]
    for value in preconditioner:
        if not value > 0:
            raise Error("Matrix diagonal must be positive")
    var residual = source.copy()
    var direction = List[Float64](length=size, fill=0.0)
    var product = List[Float64](length=size, fill=0.0)
    var residual_norm = Float64(0)
    var residual_dot_preconditioned = Float64(0)
    for i in range(size):
        direction[i] = residual[i] / preconditioner[i]
        residual_norm += residual[i] * residual[i]
        residual_dot_preconditioned += residual[i] * direction[i]
    var target = residual_norm * 1e-20  # Relative residual tolerance: 1e-10.

    for _ in range(2 * size):
        _apply_matrix(
            diagonal, neighbors, direction, product, boundary, correction
        )
        var denominator = Float64(0)
        for i in range(size):
            denominator += direction[i] * product[i]
        if not denominator > 0:
            raise Error("Matrix solver lost positive definiteness")
        var alpha = residual_dot_preconditioned / denominator
        residual_norm = 0.0
        for i in range(size):
            field[i] += alpha * direction[i]
            residual[i] -= alpha * product[i]
            residual_norm += residual[i] * residual[i]

        if residual_norm <= target:
            # Verify the actual residual, not only the recursive estimate.
            _apply_matrix(
                diagonal, neighbors, field, product, boundary, correction
            )
            residual_norm = 0.0
            for i in range(size):
                residual[i] = source[i] - product[i]
                residual_norm += residual[i] * residual[i]
            if residual_norm <= target:
                return field^
            residual_dot_preconditioned = 0.0
            for i in range(size):
                direction[i] = residual[i] / preconditioner[i]
                residual_dot_preconditioned += residual[i] * direction[i]
            continue

        var next_dot = Float64(0)
        for i in range(size):
            next_dot += residual[i] * residual[i] / preconditioner[i]
        var beta = next_dot / residual_dot_preconditioned
        for i in range(size):
            direction[i] = residual[i] / preconditioner[i] + beta * direction[i]
        residual_dot_preconditioned = next_dot

    raise Error("Matrix solver did not converge; no particle was added")
