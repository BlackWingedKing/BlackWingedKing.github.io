"""Cardinal random walks accelerated by precomputed square first-exit laws."""

from std.builtin.globals import global_constant
from std.collections import Array
from std.math import acosh, cos, exp, pi, sin
from std.random import random_float64, random_si64
from algorithms import random_walk
from grid import Grid


struct SquareExitCache:
    var distances: List[Int]
    var pending: List[Int]

    def __init__(out self):
        self.distances = List[Int]()
        self.pending = List[Int]()

    def invalidate(mut self):
        self.distances.clear()
        self.pending.clear()

    def prepare[num_cols: Int, num_rows: Int](mut self, cells: List[Int]):
        if len(self.distances) != 0:
            return
        self.distances = List[Int](
            length=len(cells), fill=max(num_cols, num_rows)
        )
        for index in range(len(cells)):
            if cells[index] != 0:
                self.distances[index] = 0
                self.pending.append(index)
        self._propagate[num_cols, num_rows]()

    def add_particle[num_cols: Int, num_rows: Int](mut self, index: Int):
        if len(self.distances) == 0 or self.distances[index] == 0:
            return
        self.distances[index] = 0
        self.pending.append(index)
        self._propagate[num_cols, num_rows]()

    def _propagate[num_cols: Int, num_rows: Int](mut self):
        # Eight-neighbor distances measure the largest empty centered square.
        var head = 0
        while head < len(self.pending):
            var index = self.pending[head]
            var x = index % num_cols
            var y = index // num_cols
            var distance = self.distances[index] + 1
            comptime for dy in range(-1, 2):
                comptime for dx in range(-1, 2):
                    comptime if dx != 0 or dy != 0:
                        var nx = x + dx
                        var ny = y + dy
                        if 0 <= nx < num_cols and 0 <= ny < num_rows:
                            var neighbor = ny * num_cols + nx
                            if self.distances[neighbor] > distance:
                                self.distances[neighbor] = distance
                                self.pending.append(neighbor)
            head += 1
        self.pending.clear()


def _exit_cdf[radius: Int]() -> Array[Float64, 2 * radius - 1]:
    """Conditional side CDF from the discrete Poisson kernel (Lawler, 8.1).

    For side offset k, its mass is (2/r) sum over odd m of
    sin(m*pi/2) * sin(m*pi*(k+r)/(2*r)) / cosh(r*acosh(2-cos(m*pi/(2*r)))).
    """
    comptime assert radius > 0
    var coefficients = Array[Float64, radius](fill=0)
    for mode in range(radius):
        var harmonic = 2 * mode + 1
        var theta = Float64(harmonic) * pi / Float64(2 * radius)
        var decay = exp(-Float64(radius) * acosh(2 - cos(theta)))
        var sign = Float64(1 if mode % 2 == 0 else -1)
        # Stable sech avoids overflowing cosh for large squares.
        coefficients[mode] = (
            sign * 4 / Float64(radius) * decay / (1 + decay * decay)
        )

    var cdf = Array[Float64, 2 * radius - 1](fill=0)
    var total = Float64(0)
    for position in range(2 * radius - 1):
        var probability = Float64(0)
        for mode in range(radius):
            var theta = Float64(2 * mode + 1) * pi / Float64(2 * radius)
            probability += coefficients[mode] * sin(
                theta * Float64(position + 1)
            )
        total += max(Float64(0), probability)
        cdf[position] = total
    for position in range(2 * radius - 1):
        cdf[position] /= total
    cdf[2 * radius - 2] = 1
    return cdf^


def _sample_exit[radius: Int](pos: Tuple[Int, Int]) -> Tuple[Int, Int]:
    comptime table = _exit_cdf[radius]()
    ref cdf = global_constant[table]()
    var draw = random_float64(0, 1)
    var low = 0
    var high = 2 * radius - 2
    while low < high:
        var middle = (low + high) // 2
        if draw < cdf[middle]:
            high = middle
        else:
            low = middle + 1
    var offset = low - radius + 1
    match Int(random_si64(0, 3)):
        case 0:
            return (pos[0] + radius, pos[1] + offset)
        case 1:
            return (pos[0] - radius, pos[1] + offset)
        case 2:
            return (pos[0] + offset, pos[1] + radius)
        case _:
            return (pos[0] + offset, pos[1] - radius)


def _jump[
    radius: Int
](pos: Tuple[Int, Int], safe_radius: Int) -> Tuple[Int, Int]:
    comptime if radius > 2:
        if safe_radius < radius:
            return _jump[radius // 2](pos, safe_radius)
    return _sample_exit[radius](pos)


def _largest_radius(limit: Int) -> Int:
    var radius = 1
    while radius * 2 <= limit:
        radius *= 2
    return radius


def spawn_and_stick[
    num_cols: Int, num_rows: Int
](mut grid: Grid[num_cols, num_rows], *, stickiness: Float64 = 1.0) -> Optional[
    Tuple[Int, Int]
]:
    random_walk.spawn_particle(grid)
    if not grid.current_particle_pos:
        return None
    grid._square_exit.prepare[num_cols, num_rows](grid.cells)
    comptime max_radius = _largest_radius((min(num_cols, num_rows) - 1) // 2)
    while grid.current_particle_pos:
        var pos = grid.current_particle_pos.value()
        var index = Grid[num_cols, num_rows].to_index(pos[0], pos[1])
        # Leave the attachment layer outside the square's interior.
        var safe_radius = grid._square_exit.distances[index] - 1
        safe_radius = min(safe_radius, min(pos[0], num_cols - 1 - pos[0]))
        safe_radius = min(safe_radius, min(pos[1], num_rows - 1 - pos[1]))
        comptime if max_radius >= 2:
            if safe_radius >= 2:
                grid.current_particle_pos = _jump[max_radius](pos, safe_radius)
                continue
        var stuck = random_walk.walk_particle(grid, stickiness=stickiness)
        if stuck:
            return stuck
    return None


def main() raises:
    from std.testing import assert_equal, assert_true

    comptime table = _exit_cdf[2]()
    ref cdf = global_constant[table]()
    assert_true(abs(cdf[0] - 0.25) < 1e-10)
    assert_true(abs(cdf[1] - 0.75) < 1e-10)
    assert_equal(cdf[2], Float64(1))

    var grid = Grid[13, 9]()
    for particle in range(35):
        var stuck = spawn_and_stick(grid)
        assert_true(Bool(stuck))
        assert_true(grid._touches_cluster(stuck.value()))
        var occupied_count = 0
        for cell in grid.cells:
            occupied_count += cell
        assert_equal(occupied_count, particle + 2)
        for index in range(grid.count):
            var expected = max(13, 9)
            var pos = Grid[13, 9].to_coord(index)
            for occupied in range(grid.count):
                if grid.cells[occupied] != 0:
                    var coord = Grid[13, 9].to_coord(occupied)
                    expected = min(
                        expected,
                        max(abs(pos[0] - coord[0]), abs(pos[1] - coord[1])),
                    )
            assert_equal(grid._square_exit.distances[index], expected)

    grid[(0, 0)] = 1
    assert_equal(grid._square_exit.distances[0], 0)
    grid[(0, 0)] = 0
    assert_equal(len(grid._square_exit.distances), 0)
    grid._square_exit.prepare[13, 9](grid.cells)
    assert_true(grid._square_exit.distances[0] > 0)
    for index in range(2 * (13 + 9 - 2)):
        grid[Grid[13, 9]._boundary_coord(index)] = 1
    assert_true(not spawn_and_stick(grid))
    var narrow = Grid[2, 5]()
    assert_true(Bool(spawn_and_stick(narrow)))
    var partial = Grid[19, 13]()
    for _ in range(30):
        var stuck = partial.spawn_and_stick_particle(
            algorithm=.square_exit, stickiness=0.1
        )
        assert_true(Bool(stuck))
        assert_true(partial._touches_cluster(stuck.value()))
    var occupied_count = 0
    for cell in partial.cells:
        occupied_count += cell
    assert_equal(occupied_count, 31)
    print("Square-exit probabilities, growth, distance cache, and edges passed")
