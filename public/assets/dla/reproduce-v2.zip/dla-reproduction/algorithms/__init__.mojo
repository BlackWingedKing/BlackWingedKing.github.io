"""Particle attachment algorithms."""
