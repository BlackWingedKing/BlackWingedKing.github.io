"""Uniform boundary spawning followed by a cardinal random walk."""

from std.random import random_float64, random_si64
from grid import Grid


def spawn_and_stick[
    num_cols: Int, num_rows: Int
](mut grid: Grid[num_cols, num_rows], *, stickiness: Float64 = 1.0) -> Optional[
    Tuple[Int, Int]
]:
    spawn_particle(grid)
    var stuck: Optional[Tuple[Int, Int]] = None
    while grid.current_particle_pos:
        stuck = walk_particle(grid, stickiness=stickiness)
    return stuck


def spawn_particle[
    num_cols: Int, num_rows: Int
](mut grid: Grid[num_cols, num_rows]):
    """Spawns uniformly on an empty boundary cell, or None if full."""
    comptime perimeter = 2 * (num_cols + num_rows - 2)
    grid.current_particle_pos = None
    var empty_cells = List[Tuple[Int, Int]]()
    for index in range(perimeter):
        var coord = Grid[num_cols, num_rows]._boundary_coord(index)
        if grid[coord] == 0:
            empty_cells.append(coord)

    if len(empty_cells) == 0:
        return

    var selected = Int(random_si64(0, Int64(len(empty_cells) - 1)))
    grid.current_particle_pos = empty_cells[selected]


def walk_particle[
    num_cols: Int, num_rows: Int
](mut grid: Grid[num_cols, num_rows], *, stickiness: Float64 = 1.0) -> Optional[
    Tuple[Int, Int]
]:
    """Try sticking once at contact; after rejection, take a cardinal step."""
    if not grid.current_particle_pos:
        return None

    var pos = grid.current_particle_pos.value()
    if grid._touches_cluster(pos) and (
        stickiness == 1.0 or random_float64(0, 1) < stickiness
    ):
        grid[pos] = 1
        grid.current_particle_pos = None
        return pos

    var x = pos[0]
    var y = pos[1]
    match Int(random_si64(0, 3)):
        case 0:
            x += 1
        case 1:
            x -= 1
        case 2:
            y += 1
        case _:
            y -= 1
    if grid.is_valid_coord((x, y)) and grid[(x, y)] == 0:
        pos = (x, y)

    # Preserve immediate first-contact attachment and RNG use for p=1.
    if stickiness == 1.0 and grid._touches_cluster(pos):
        grid[pos] = 1
        grid.current_particle_pos = None
        return pos

    grid.current_particle_pos = pos
    return None


def _validate_stickiness(stickiness: Float64) raises:
    if not (stickiness > 0.0 and stickiness <= 1.0):
        raise Error("stickiness must be greater than 0 and at most 1")


def main() raises:
    from std.random import seed
    from std.testing import assert_equal, assert_raises, assert_true
    from grid import Algorithm

    # A surrounded empty site detects extra trials and entry into occupied cells.
    var grid = Grid[5, 5]()
    grid[(2, 2)] = 0
    for coord in [(1, 2), (3, 2), (2, 1), (2, 3)]:
        grid[coord] = 1
    seed(42)
    var successes = 0
    for _ in range(20000):
        grid.current_particle_pos = (2, 2)
        if walk_particle(grid, stickiness=0.25):
            successes += 1
            grid[(2, 2)] = 0
        else:
            assert_equal(grid.current_particle_pos.value(), (2, 2))
            assert_equal(grid[(2, 2)], 0)
    assert_true(abs(Float64(successes) / 20000 - 0.25) < 0.02)

    var mobile = Grid[7, 7]()
    mobile.current_particle_pos = (2, 3)
    var moved = False
    for _ in range(100):
        assert_true(not walk_particle(mobile, stickiness=1e-15))
        var pos = mobile.current_particle_pos.value()
        assert_equal(mobile[pos], 0)
        moved = moved or pos != (2, 3)
    assert_true(moved)
    for probability in [0.0, -0.1, 1.1]:
        with assert_raises():
            _ = mobile.spawn_and_stick_particle(stickiness=probability)
        with assert_raises():
            _ = mobile.walk_particle(stickiness=probability)
    for algorithm in [
        Algorithm.matrix,
        Algorithm.matrix_gpu,
        Algorithm.rectangle,
    ]:
        with assert_raises():
            _ = mobile.spawn_and_stick_particle(
                algorithm=algorithm, stickiness=0.5
            )
    print(
        "Stickiness trials, rejection movement, and occupied-cell checks passed"
    )
