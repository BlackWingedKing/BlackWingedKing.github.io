"""Attachment probabilities from the full grid or a reduced rectangle."""

from std.random import random_si64
from grid import Grid
from algorithms.linear_solver import solve_matrix


def inside_rectangle[
    num_cols: Int
](index: Int, bounds: Tuple[Int, Int, Int, Int]) -> Bool:
    var x = index % num_cols
    var y = index // num_cols
    return bounds[0] <= x <= bounds[2] and bounds[1] <= y <= bounds[3]


def attachment_probabilities[
    num_cols: Int, num_rows: Int, *, use_gpu: Bool = False
](grid: Grid[num_cols, num_rows]) raises -> List[Float64]:
    """Return a grid-sized probability array for the existing cardinal walk."""
    return solve_attachment_probabilities[use_gpu=use_gpu](
        grid,
        (0, 0, num_cols - 1, num_rows - 1),
        [],
        [],
        [],
    )


def solve_attachment_probabilities[
    num_cols: Int, num_rows: Int, *, use_gpu: Bool = False
](
    grid: Grid[num_cols, num_rows],
    bounds: Tuple[Int, Int, Int, Int],
    interface: List[Int],
    correction: List[Float64],
    exterior_source: List[Float64],
) raises -> List[Float64]:
    var probabilities = List[Float64](length=grid.count, fill=0.0)
    var attachment = List[Bool](length=grid.count, fill=False)
    for y in range(bounds[1], bounds[3] + 1):
        for x in range(bounds[0], bounds[2] + 1):
            var index = Grid[num_cols, num_rows].to_index(x, y)
            if grid.cells[index] == 0:
                attachment[index] = grid._touches_cluster((x, y))

    comptime perimeter = 2 * (num_cols + num_rows - 2)
    var border = List[Int]()
    for i in range(perimeter):
        var coord = Grid[num_cols, num_rows]._boundary_coord(i)
        if grid[coord] == 0:
            border.append(Grid[num_cols, num_rows].to_index(coord[0], coord[1]))
    if len(border) == 0:
        return probabilities^
    var start_probability = 1.0 / Float64(len(border))

    # Only reachable transient cells belong in A; sealed pockets are irrelevant.
    var active = List[Int]()
    var local_index = List[Int](length=grid.count, fill=-1)
    for index in border:
        if not inside_rectangle[num_cols](index, bounds):
            continue
        if attachment[index]:
            probabilities[index] = start_probability
        else:
            local_index[index] = len(active)
            active.append(index)
    for index in interface:
        if grid.cells[index] != 0 or attachment[index]:
            raise Error(
                "Rectangle interface must have an empty nonattachment margin"
            )
        if local_index[index] < 0:
            local_index[index] = len(active)
            active.append(index)
    var head = 0
    while head < len(active):
        var index = active[head]
        var adjacent = Grid[num_cols, num_rows].neighbors(index)
        comptime for direction in range(4):
            var neighbor = adjacent[direction]
            if neighbor >= 0 and inside_rectangle[num_cols](neighbor, bounds):
                if (
                    grid.cells[neighbor] == 0
                    and not attachment[neighbor]
                    and local_index[neighbor] < 0
                ):
                    local_index[neighbor] = len(active)
                    active.append(neighbor)
        head += 1

    var size = len(active)
    var diagonal = List[Float64](length=size, fill=0.0)
    var neighbors = List[Int](length=4 * size, fill=-1)
    var source = List[Float64](length=size, fill=0.0)
    for index in border:
        if inside_rectangle[num_cols](index, bounds) and not attachment[index]:
            source[local_index[index]] = start_probability
    var boundary = List[Int]()
    for i in range(len(interface)):
        var local = local_index[interface[i]]
        boundary.append(local)
        source[local] += exterior_source[i] * start_probability
    for i in range(size):
        var adjacent = Grid[num_cols, num_rows].neighbors(active[i])
        comptime for direction in range(4):
            var neighbor = adjacent[direction]
            if neighbor >= 0 and grid.cells[neighbor] == 0:
                diagonal[i] += 1.0
                neighbors[4 * i + direction] = local_index[neighbor]

    # A is the grounded graph Laplacian: valid degree minus transient neighbors.
    # Invalid-step self-loops in random_walk cancel out of this hitting equation.
    var field: List[Float64]
    comptime if use_gpu:
        from algorithms.gpu_solver import solve_matrix_gpu

        if len(boundary) != 0:
            raise Error("matrix_gpu currently supports full-grid solves only")
        field = solve_matrix_gpu[num_cols * num_rows](
            diagonal, neighbors, source
        )
    else:
        field = solve_matrix(diagonal, neighbors, source, boundary, correction)
    for i in range(size):
        if not field[i] >= -1e-12:
            raise Error("Matrix solver produced an invalid probability field")
        var value = max(field[i], Float64(0))
        var adjacent = Grid[num_cols, num_rows].neighbors(active[i])
        comptime for direction in range(4):
            var neighbor = adjacent[direction]
            if neighbor >= 0 and attachment[neighbor]:
                probabilities[neighbor] += value

    var total = Float64(0)
    for probability in probabilities:
        total += probability
    if not abs(total - 1.0) <= 1e-8:
        raise Error("Matrix attachment probabilities do not sum to one")
    for i in range(grid.count):
        probabilities[i] /= total
    return probabilities^


def stick_from_probabilities[
    num_cols: Int, num_rows: Int
](mut grid: Grid[num_cols, num_rows], probabilities: List[Float64]) -> Optional[
    Tuple[Int, Int]
]:
    # Draw 53 random bits to match Float64's significand precision.
    var threshold = (
        Float64(random_si64(0, 9007199254740991)) / 9007199254740992.0
    )
    var cumulative = Float64(0)
    var last: Optional[Tuple[Int, Int]] = None
    for index in range(grid.count):
        if probabilities[index] > 0:
            last = Grid[num_cols, num_rows].to_coord(index)
            cumulative += probabilities[index]
            if threshold < cumulative:
                grid[last.value()] = 1
                return last
    # Covers final-bit rounding, or returns None when the border is full.
    if last:
        grid[last.value()] = 1
    return last


def spawn_and_stick[
    num_cols: Int, num_rows: Int
](mut grid: Grid[num_cols, num_rows]) raises -> Optional[Tuple[Int, Int]]:
    grid.current_particle_pos = None
    var probabilities = attachment_probabilities(grid)
    return stick_from_probabilities(grid, probabilities)
