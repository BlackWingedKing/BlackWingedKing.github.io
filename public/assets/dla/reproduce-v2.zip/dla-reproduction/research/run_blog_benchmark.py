"""Reproduce the blog comparison without changing the simulation sources."""

import argparse
import hashlib
import json
import platform
import shutil
import statistics
import subprocess
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SEEDS = [42, 43, 44, 45, 46]
ALGORITHMS = ["random_walk", "square_exit"]


def command(*args):
    return subprocess.check_output(args, cwd=ROOT, text=True).strip()


def parse_run(text, count, capture):
    lines = text.splitlines()
    kind, compute, loop, init, early, checksum = lines[0].split()
    assert kind == "summary"
    result = dict(zip(
        ["compute_ns", "loop_ns", "grid_init_ns", "first_500_ns", "checksum"],
        map(int, [compute, loop, init, early, checksum]),
    ))
    assert 0 < result["compute_ns"] <= result["loop_ns"]
    events = []
    occupied = {(250, 250)}
    last_time = 0
    for i, line in enumerate(lines[1:], 1):
        kind, number, x, y, elapsed = line.split()
        number, x, y, elapsed = map(int, [number, x, y, elapsed])
        assert kind == "event" and number == i
        assert 0 <= x < 501 and 0 <= y < 501
        assert (x, y) not in occupied
        assert any((x + dx, y + dy) in occupied for dx, dy in
                   [(1, 0), (-1, 0), (0, 1), (0, -1)])
        assert elapsed > last_time
        occupied.add((x, y))
        last_time = elapsed
        events.append([x, y, elapsed])
    assert len(events) == (count if capture else 0)
    if capture:
        assert last_time == result["compute_ns"]
        assert sum(x + 501 * y for x, y, _ in events) == result["checksum"]
    return result, events


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--particles", type=int, default=2000)
    parser.add_argument("--output", type=Path, default=ROOT / "research/blog-results")
    args = parser.parse_args()
    assert args.particles >= 500
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    sources = [ROOT / "grid.mojo", ROOT / "research/blog_benchmark.mojo",
               *sorted((ROOT / "algorithms").glob("*.mojo"))]
    hashes = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sources}
    manifest = output / "benchmark.json"
    if manifest.exists():
        old = json.loads(manifest.read_text())
        if old["source_sha256"] == hashes and old["particles"] == args.particles and old.get("complete"):
            print("Matching completed results already exist:", manifest)
            return
        raise RuntimeError("Use a new output directory to preserve existing evidence")

    metadata = {
        "date": time.strftime("%Y-%m-%d"),
        "source_revision": command("git", "rev-parse", "HEAD") if (ROOT / ".git").exists() else "unversioned source archive (see hashes)",
        "source_sha256": hashes,
        "hardware": command("/usr/sbin/sysctl", "-n", "machdep.cpu.brand_string"),
        "memory_bytes": int(command("/usr/sbin/sysctl", "-n", "hw.memsize")),
        "os": platform.mac_ver()[0],
        "compiler": command(str(ROOT / ".venv/bin/mojo"), "--version"),
        "grid": [501, 501], "particles": args.particles, "stickiness": 1.0,
        "seeds": SEEDS, "demo_seed": SEEDS[0],
        "build": "mojo build -O3 -I <temporary CPU source copy> research/blog_benchmark.mojo -o <binary>",
        "build_adjustment": "Temporary grid copy excludes matrix_gpu import and replaces only its dispatch with an error; CPU algorithm sources unchanged. Required because installed Metal compiler component is unavailable.",
        "timing": "Sum of spawn_and_stick_particle wall-clock durations; includes square-cache initialization and updates. Excludes grid construction, event capture, output, plotting, compilation. loop_ns includes timing and capture overhead. Both capture modes retain per-particle timers.",
        "runs": [], "complete": False,
    }
    with tempfile.TemporaryDirectory(prefix="dla-blog-cpu-") as temporary:
        stage = Path(temporary)
        for source in sources:
            dest = stage / source.relative_to(ROOT)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, dest)
        grid = stage / "grid.mojo"
        text = grid.read_text()
        assert text.count("matrix, matrix_gpu, random_walk") == 1
        assert text.count("return matrix_gpu.spawn_and_stick(self)") == 1
        grid.write_text(text.replace("matrix, matrix_gpu, random_walk", "matrix, random_walk")
                        .replace("return matrix_gpu.spawn_and_stick(self)",
                                 'raise Error("GPU backend excluded from CPU benchmark build")'))
        binary = stage / "benchmark"
        subprocess.run([str(ROOT / ".venv/bin/mojo"), "build", "-O3", "-I", str(stage),
                        str(stage / "research/blog_benchmark.mojo"), "-o", str(binary)], check=True)
        # Warm each code path in a separate process; every measured run gets a fresh grid/cache.
        for algorithm in ALGORITHMS:
            command(str(binary), algorithm, "1", "10", "0")
        for index, run_seed in enumerate(SEEDS):
            algorithms = ALGORITHMS if index % 2 == 0 else ALGORITHMS[::-1]
            modes = [True, False] if index % 2 == 0 else [False, True]
            for capture in modes:
                for algorithm in algorithms:
                    started = time.perf_counter()
                    raw = command(str(binary), algorithm, str(run_seed), str(args.particles), str(int(capture)))
                    process_seconds = time.perf_counter() - started
                    result, events = parse_run(raw, args.particles, capture)
                    result.update(algorithm=algorithm, seed=run_seed, capture=capture,
                                  process_seconds=process_seconds)
                    metadata["runs"].append(result)
                    if capture:
                        (output / f"{algorithm}-{run_seed}.json").write_text(json.dumps(events))
                    manifest.write_text(json.dumps(metadata, indent=2) + "\n")
                    print(algorithm, run_seed, "capture" if capture else "timing-only",
                          f'{result["compute_ns"] / 1e9:.3f}s', flush=True)

    for algorithm in ALGORITHMS:
        for run_seed in SEEDS:
            runs = [r for r in metadata["runs"] if r["algorithm"] == algorithm and r["seed"] == run_seed]
            assert len(runs) == 2 and runs[0]["checksum"] == runs[1]["checksum"]
    metadata["statistics"] = {}
    for algorithm in ALGORITHMS:
        captured = [r for r in metadata["runs"] if r["algorithm"] == algorithm and r["capture"]]
        baseline = [r for r in metadata["runs"] if r["algorithm"] == algorithm and not r["capture"]]
        seconds = [r["compute_ns"] / 1e9 for r in captured]
        metadata["statistics"][algorithm] = {
            "median_seconds": statistics.median(seconds), "min_seconds": min(seconds), "max_seconds": max(seconds),
            "first_500_median_seconds": statistics.median(r["first_500_ns"] / 1e9 for r in captured),
            "remaining_median_seconds": statistics.median((r["compute_ns"] - r["first_500_ns"]) / 1e9 for r in captured),
            "timing_only_median_seconds": statistics.median(r["compute_ns"] / 1e9 for r in baseline),
            "max_loop_overhead_seconds": max((r["loop_ns"] - r["compute_ns"]) / 1e9 for r in captured),
        }
    metadata["complete"] = True
    manifest.write_text(json.dumps(metadata, indent=2) + "\n")
    print(json.dumps(metadata["statistics"], indent=2))


if __name__ == "__main__":
    main()
