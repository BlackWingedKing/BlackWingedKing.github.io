"""Small, independently solved absorbing chain for the article's live figure."""

import json
from pathlib import Path

import numpy as np


def probabilities():
    size = 9
    occupied = {(4, 4), (5, 4), (4, 5), (4, 3)}
    directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    free = [(x, y) for y in range(size) for x in range(size) if (x, y) not in occupied]
    contact = [p for p in free if any((p[0] + dx, p[1] + dy) in occupied for dx, dy in directions)]
    transient = [p for p in free if p not in contact]
    ti, ai = {p: i for i, p in enumerate(transient)}, {p: i for i, p in enumerate(contact)}
    q = np.zeros((len(transient), len(transient)))
    r = np.zeros((len(transient), len(contact)))
    for p, i in ti.items():
        for dx, dy in directions:
            n = (p[0] + dx, p[1] + dy)
            if n not in free:
                n = p
            if n in ai:
                r[i, ai[n]] += 0.25
            else:
                q[i, ti[n]] += 0.25
    boundary = [p for p in free if 0 in p or size - 1 in p]
    mu = np.zeros(len(transient))
    direct = np.zeros(len(contact))
    for p in boundary:
        if p in ti:
            mu[ti[p]] += 1 / len(boundary)
        else:
            direct[ai[p]] += 1 / len(boundary)
    visits = np.linalg.solve(np.eye(len(transient)) - q.T, mu)
    mass = direct + r.T @ visits
    assert np.allclose(q.sum(axis=1) + r.sum(axis=1), 1)
    assert mass.min() > 0 and abs(mass.sum() - 1) < 1e-12
    return {"size": size, "occupied": sorted(occupied),
            "sites": [{"x": x, "y": y, "probability": float(mass[i]), "label": chr(65 + i)}
                      for i, (x, y) in enumerate(contact)],
            "model": "Uniform empty outer-boundary launch; four equal cardinal attempts; blocked steps stay; p=1; one fixed 9x9 cluster.",
            "sum": float(mass.sum())}


if __name__ == "__main__":
    import sys
    Path(sys.argv[1]).write_text(json.dumps(probabilities(), indent=2) + "\n")
