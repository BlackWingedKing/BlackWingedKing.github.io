"""Measure all five existing methods on one fixed workload, sequentially."""

import argparse
import hashlib
import json
import platform
import statistics
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "research/method-results"
METHODS = ["random_walk", "matrix", "rectangle", "matrix_gpu", "square_exit"]
SEEDS = [42, 43, 44, 45, 46]
SIZE, COUNT = 101, 200


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=OUTPUT)
    parser.add_argument("--binary", type=Path, default=Path("/tmp/dla-method-benchmark"))
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    manifest = output / "benchmark.json"
    if manifest.exists():
        raise RuntimeError("Preserve existing evidence; move results before a new measurement")
    sources = [ROOT / "grid.mojo", ROOT / "research/method_benchmark.mojo",
               *sorted((ROOT / "algorithms").glob("*.mojo"))]
    data = {
        "date": time.strftime("%Y-%m-%d"), "grid": [SIZE, SIZE], "particles": COUNT,
        "stickiness": 1.0, "seeds": SEEDS, "demo_seed": 42, "methods": METHODS,
        "source_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip() if (ROOT / ".git").exists() else "unversioned source archive (see hashes)",
        "source_sha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
        "hardware": subprocess.check_output(["/usr/sbin/sysctl", "-n", "machdep.cpu.brand_string"], text=True).strip(),
        "memory_bytes": int(subprocess.check_output(["/usr/sbin/sysctl", "-n", "hw.memsize"], text=True)), "os": platform.mac_ver()[0],
        "compiler": subprocess.check_output([str(ROOT / ".venv/bin/mojo"), "--version"], text=True).strip(),
        "build": ".venv/bin/mojo build -O3 -I . research/method_benchmark.mojo -o /tmp/dla-method-benchmark",
        "timing": "Sum of public spawn-and-stick call durations. Includes rectangle/square caches, GPU context/buffers/transfers, runtime kernel setup and CPU refinement. Excludes ahead-of-time compilation, initial grid construction, event storage/export and rendering. Each run is a fresh process/grid; no in-process warmup. loop_ns includes per-particle timer/capture overhead.",
        "protocol": "101 x 101 / 200 particles chosen after a 20-particle pilot at seed 2026; then fixed. Five seeds, cyclic method order. Recorded separately without concurrent simulation or rendering. Seed 42 selected for 1x replay before main results.",
        "runs": [], "complete": False,
    }
    binary = str(args.binary.resolve())
    for index, seed in enumerate(SEEDS):
        for method in METHODS[index:] + METHODS[:index]:
            start = time.perf_counter()
            raw = subprocess.check_output([binary, method, str(seed), str(COUNT), "1"], text=True, timeout=300)
            process_seconds = time.perf_counter() - start
            lines = raw.splitlines()
            tag, compute, loop, init, early, checksum = lines[0].split()
            assert tag == "summary"
            events = []
            occupied = {(SIZE // 2, SIZE // 2)}
            last = 0
            for number, line in enumerate(lines[1:], 1):
                tag, n, x, y, elapsed = line.split()
                n, x, y, elapsed = map(int, [n, x, y, elapsed])
                assert tag == "event" and n == number
                assert 0 <= x < SIZE and 0 <= y < SIZE and (x, y) not in occupied
                assert any((x + dx, y + dy) in occupied for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)])
                assert elapsed > last
                last = elapsed
                occupied.add((x, y))
                events.append([x, y, elapsed])
            assert len(events) == COUNT and last == int(compute)
            assert sum(x + SIZE * y for x, y, _ in events) == int(checksum)
            run = dict(method=method, seed=seed, compute_ns=int(compute), loop_ns=int(loop),
                       grid_init_ns=int(init), first_50_ns=int(early), checksum=int(checksum),
                       process_seconds=process_seconds)
            data["runs"].append(run)
            (output / f"{method}-{seed}.json").write_text(json.dumps(events))
            manifest.write_text(json.dumps(data, indent=2) + "\n")
            print(method, seed, f'{int(compute)/1e9:.6f}s', flush=True)
    data["statistics"] = {}
    for method in METHODS:
        runs = [r for r in data["runs"] if r["method"] == method]
        values = [r["compute_ns"] / 1e9 for r in runs]
        data["statistics"][method] = dict(median_seconds=statistics.median(values),
            min_seconds=min(values), max_seconds=max(values),
            first_50_median_seconds=statistics.median(r["first_50_ns"] / 1e9 for r in runs),
            max_loop_overhead_seconds=max((r["loop_ns"] - r["compute_ns"]) / 1e9 for r in runs))
    data["complete"] = True
    manifest.write_text(json.dumps(data, indent=2) + "\n")
    print(json.dumps(data["statistics"], indent=2))


if __name__ == "__main__":
    main()
