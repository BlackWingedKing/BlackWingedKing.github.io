"""A 1x, shared-computation-clock replay of five separately measured methods."""

import argparse
import shutil
import json
import math
import subprocess
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "research/method-results"
W, H, FPS = 1440, 1170, 30
BG, FG, MUTED = (11, 16, 32), (241, 245, 249), (148, 163, 184)
CYAN, GOLD = (34, 211, 238), (253, 230, 138)


def font(size, bold=False):
    name = "Arial Bold.ttf" if bold else "Arial.ttf"
    return ImageFont.truetype("/System/Library/Fonts/Supplemental/" + name, size)


def seconds(value):
    return f"{value:.3f} s" if value < 1 else f"{value:.2f} s"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, default=RESULTS)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    results, output = args.results, args.output
    encoder_path = shutil.which("ffmpeg")
    if not encoder_path:
        raise RuntimeError("Install ffmpeg and put it on PATH")
    meta = json.loads((results / "benchmark.json").read_text())
    assert meta["complete"] and meta["grid"] == [101, 101] and meta["particles"] == 200
    methods = meta["methods"]
    labels = ["Random walk · CPU", "Matrix · CPU", "Rectangle · CPU", "Matrix · GPU", "Square exits · CPU"]
    arrays = [np.array(json.loads((results / f"{m}-42.json").read_text()), dtype=np.int64) for m in methods]
    for data in arrays:
        assert data.shape == (200, 3) and np.all(np.diff(data[:, 2]) > 0)
        assert np.all((data[:, :2] >= 0) & (data[:, :2] < 101))
    finishes = [int(data[-1, 2]) for data in arrays]
    end = 8.0
    colors = np.stack([np.interp(np.linspace(0, 2, 201), [0, 1, 2], c)
                       for c in [(167, 34, 253), (139, 211, 230), (250, 238, 138)]], axis=1).astype(np.uint8)
    title, label, small, clock_font = font(43, True), font(25, True), font(19), font(62, True)

    def frame(t):
        image = Image.new("RGB", (W, H), BG)
        d = ImageDraw.Draw(image)
        d.text((36, 24), "Five methods. One growth rule.", font=title, fill=FG)
        d.text((36, 85), "101 × 101 lattice  /  200 particles  /  stickiness 1.0  /  seed 42", font=font(24), fill=MUTED)
        for i, (events, name) in enumerate(zip(arrays, labels)):
            x, y = 36 + (i % 3) * 468, 144 + (i // 3) * 468
            n = int(np.searchsorted(events[:, 2], round(t * 1e9), side="right"))
            d.text((x, y), name, font=label, fill=FG)
            state = f"{n:3d} / 200"
            if n == 200:
                state += "  ·  " + seconds(finishes[i] / 1e9) + "  ·  done"
            else:
                state += "  ·  computing"
            d.text((x, y + 36), state, font=small, fill=CYAN if n == 200 else MUTED)
            grid = np.zeros((101, 101, 3), dtype=np.uint8)
            grid[:] = BG
            grid[50, 50] = colors[0]
            current = events[:n]
            grid[current[:, 1], current[:, 0]] = colors[1:n+1]
            image.paste(Image.fromarray(grid).resize((396, 396), Image.Resampling.NEAREST), (x, y + 66))
            d.rectangle((x, y + 66, x + 395, y + 461), outline=(39, 49, 69))
        x, y = 972, 612
        d.text((x, y + 14), "ONE SHARED CLOCK", font=small, fill=CYAN)
        d.text((x, y + 63), f"{t:05.2f} s", font=clock_font, fill=FG)
        d.text((x, y + 149), "1× COMPUTE-TIME REPLAY", font=font(22, True), fill=GOLD)
        for j, text in enumerate(["One second here = one second", "inside the spawn-and-stick call.", "", "Runs recorded separately.", "Full grids, identical scale.", "Finished panels stay frozen."]):
            d.text((x, y + 197 + j * 29), text, font=small, fill=MUTED)
        d.text((x, y + 398), "FIRST 8 SECONDS · LOOP", font=font(23, True), fill=CYAN)
        d.text((36, 1113), "Includes cache builds, GPU setup, transfers and refinement. Excludes drawing and export.", font=small, fill=MUTED)
        return image

    output.mkdir(parents=True, exist_ok=True)
    frame(end).save(output / "methods-poster.jpg", quality=91)
    frame(end / 2).save(output / "methods-midpoint.png")
    (output / "methods-replay.json").write_text(json.dumps({"playback_speed": 1, "fps": FPS,
        "demo_seed": 42, "full_grid": [101, 101], "finish_seconds": dict(zip(methods, [n/1e9 for n in finishes])),
        "duration_seconds": end, "excerpt_compute_seconds": [0, end], "loop": True}, indent=2) + "\n")
    temporary = output / "methods.partial.mp4"
    encoder = subprocess.Popen([encoder_path, "-y", "-loglevel", "error", "-f", "rawvideo",
        "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-", "-an", "-c:v", "libx264",
        "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(temporary)], stdin=subprocess.PIPE)
    try:
        for i in range(math.ceil(end * FPS)):
            encoder.stdin.write(frame(i / FPS).tobytes())
    finally:
        encoder.stdin.close()
    if encoder.wait() != 0:
        raise RuntimeError("Video encoding failed")
    temporary.replace(output / "methods.mp4")
    print(output / "methods.mp4")


if __name__ == "__main__":
    main()
