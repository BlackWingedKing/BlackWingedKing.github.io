"""All-method comparison on a common 101 x 101 lattice."""

from std.random import seed
from std.sys import argv
from std.time import perf_counter_ns
from grid import Algorithm, Grid


def main() raises:
    var args = argv()
    if len(args) != 5:
        raise Error("usage: blog_benchmark random_walk|square_exit|matrix|rectangle|matrix_gpu seed count capture(0|1)")
    var run_seed = Int(args[2])
    var count = Int(args[3])
    if count <= 0 or (args[4] != "0" and args[4] != "1"):
        raise Error("positive particle count and capture 0 or 1 required")
    var capture = args[4] == "1"
    if args[1] == "random_walk":
        run[Algorithm.random_walk](run_seed, count, capture)
    elif args[1] == "square_exit":
        run[Algorithm.square_exit](run_seed, count, capture)
    elif args[1] == "matrix":
        run[Algorithm.matrix](run_seed, count, capture)
    elif args[1] == "rectangle":
        run[Algorithm.rectangle](run_seed, count, capture)
    elif args[1] == "matrix_gpu":
        run[Algorithm.matrix_gpu](run_seed, count, capture)
    else:
        raise Error("unknown algorithm")


def run[algorithm: Algorithm](run_seed: Int, count: Int, capture: Bool) raises:
    seed(run_seed)
    var init_started = perf_counter_ns()
    var grid = Grid[101, 101]()
    var init_ns = perf_counter_ns() - init_started
    var positions = List[Tuple[Int, Int]](length=count, fill=(0, 0))
    var elapsed = List[Int](length=count, fill=0)
    var total_ns = 0
    var first_50_ns = 0
    var checksum = 0
    var run_started = perf_counter_ns()
    for i in range(count):
        var started = perf_counter_ns()
        var stuck = grid.spawn_and_stick_particle(algorithm=algorithm)
        total_ns += Int(perf_counter_ns() - started)
        if not stuck:
            raise Error("boundary filled before target")
        var pos = stuck.value()
        checksum += pos[0] + 101 * pos[1]
        if i == 49:
            first_50_ns = total_ns
        if capture:
            positions[i] = pos
            elapsed[i] = total_ns
    var loop_ns = perf_counter_ns() - run_started
    var occupied = 0
    for cell in grid.cells:
        occupied += cell
    if occupied != count + 1:
        raise Error("incorrect final occupancy")
    print("summary", total_ns, loop_ns, init_ns, first_50_ns, checksum)
    if capture:
        for i in range(count):
            print("event", i + 1, positions[i][0], positions[i][1], elapsed[i])
