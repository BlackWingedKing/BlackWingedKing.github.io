"""Render a shared-clock replay of independently measured DLA runs."""

import argparse
import json
import math
import shutil
import subprocess
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
BACKGROUND = (11, 16, 32)
TEXT = (241, 245, 249)
MUTED = (148, 163, 184)
CYAN = (34, 211, 238)
GOLD = (253, 230, 138)
WIDTH, HEIGHT, FPS = 1440, 960, 30
FONT_DIR = Path("/System/Library/Fonts/Supplemental")


def font(size, bold=False):
    return ImageFont.truetype(str(FONT_DIR / ("Arial Bold.ttf" if bold else "Arial.ttf")), size)


def validate_events(events, count):
    assert events.shape == (count, 3)
    assert np.all((events[:, :2] >= 0) & (events[:, :2] < 501))
    assert np.all(np.diff(events[:, 2]) > 0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, default=ROOT / "research/blog-results")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    metadata = json.loads((args.results / "benchmark.json").read_text())
    assert metadata["complete"] and metadata["grid"] == [501, 501]
    count = metadata["particles"]
    names = ["random_walk", "square_exit"]
    labels = ["Random walk", "Square exits"]
    events = [np.array(json.loads((args.results / f"{name}-{metadata['demo_seed']}.json").read_text()), dtype=np.int64)
              for name in names]
    for data in events:
        validate_events(data, count)
        assert np.all((data[:, :2] >= 125) & (data[:, :2] < 376)), "fixed view would hide a particle"
    finish = [float(data[-1, 2]) / 1e9 for data in events]
    # The same playback multiplier applies to both algorithms, including after one finishes.
    speed = 1
    duration = 8.0
    palette = np.array([(167, 139, 250), CYAN, GOLD])
    positions = np.linspace(0, 2, count + 1)
    colors = np.stack([np.interp(positions, [0, 1, 2], palette[:, c]) for c in range(3)], axis=1).astype(np.uint8)
    title_font, subtitle_font = font(42, True), font(23)
    label_font, number_font, small_font = font(31, True), font(25), font(20)
    stats = metadata["statistics"]
    ratio = stats[names[0]]["median_seconds"] / stats[names[1]]["median_seconds"]

    def frame(seconds):
        canvas = Image.new("RGB", (WIDTH, HEIGHT), BACKGROUND)
        draw = ImageDraw.Draw(canvas)
        draw.text((48, 30), "Growing a fractal, skipping the empty space", font=title_font, fill=TEXT)
        draw.text((48, 92), f"501 × 501 grid   /   {count:,} particles   /   stickiness 1.0   /   CPU", font=subtitle_font, fill=MUTED)
        draw.text((48, 131), f"SHARED COMPUTE CLOCK   {min(seconds, max(finish)):05.2f} s", font=number_font, fill=CYAN)
        draw.text((1020, 136), f"REPLAY AT {speed}× SPEED", font=small_font, fill=GOLD)
        for panel, (data, label) in enumerate(zip(events, labels)):
            left = 48 + panel * 704
            settled = int(np.searchsorted(data[:, 2], round(seconds * 1e9), side="right"))
            grid = np.empty((501, 501, 3), dtype=np.uint8)
            grid[:] = BACKGROUND
            grid[250, 250] = colors[0]
            selected = data[:settled]
            grid[selected[:, 1], selected[:, 0]] = colors[1:settled + 1]
            picture = Image.fromarray(grid[125:376, 125:376]).resize((640, 640), Image.Resampling.NEAREST)
            canvas.paste(picture, (left, 244))
            draw.rectangle((left, 244, left + 639, 883), outline=(39, 49, 69), width=1)
            draw.text((left, 186), label, font=label_font, fill=TEXT)
            status = f"{settled:,} / {count:,}"
            if settled == count:
                status += f"   ·   finished in {finish[panel]:.2f} s"
            draw.text((left, 222), status, font=small_font, fill=CYAN if settled == count else MUTED)
        draw.text((48, 910), "First 8 seconds · loop · plotting excluded · seed 42 · same centered 251 × 251 view", font=small_font, fill=MUTED)
        return canvas

    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    frame(duration).save(output / "comparison-poster.jpg", quality=90)
    frame(duration).save(output / "comparison-excerpt-end.png")
    frame(duration / 2).save(output / "comparison-midpoint.png")
    ffmpeg = shutil.which("ffmpeg") or "/opt/homebrew/bin/ffmpeg"
    target = output / "comparison.mp4"
    temporary = output / "comparison.partial.mp4"
    process = subprocess.Popen([ffmpeg, "-y", "-loglevel", "error", "-f", "rawvideo", "-vcodec", "rawvideo",
                                "-pix_fmt", "rgb24", "-s", f"{WIDTH}x{HEIGHT}", "-r", str(FPS), "-i", "-",
                                "-an", "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p",
                                "-movflags", "+faststart", str(temporary)], stdin=subprocess.PIPE)
    try:
        for index in range(math.ceil(duration * FPS)):
            playback = index / FPS
            compute_time = playback * speed
            process.stdin.write(frame(compute_time).tobytes())
    finally:
        process.stdin.close()
    if process.wait() != 0:
        raise RuntimeError("Video encoding failed")
    temporary.replace(target)
    (output / "replay.json").write_text(json.dumps({"fps": FPS, "size": [WIDTH, HEIGHT], "view_bounds": [125, 125, 376, 376], "playback_speed": speed,
        "duration_seconds": duration, "excerpt_compute_seconds": [0, duration * speed], "loop": True, "demo_seed": metadata["demo_seed"], "finish_seconds": dict(zip(names, finish)),
        "median_speedup": ratio}, indent=2) + "\n")
    print(target)


if __name__ == "__main__":
    main()
