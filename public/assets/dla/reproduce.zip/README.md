# Reproduce the DLA blog comparison

Original measurement: 2026-11-06, Apple M3 Pro (36 GB), macOS; Mojo 1.2.0.
See research/blog-results/benchmark.json for OS version, exact timings,
compiler, source hashes, build flags, and measurement boundaries.

The simulation sources are from revision 09a35cf790ef0bd14d719e9cb411e475a1b7f607.
No simulation behavior was edited for this benchmark. The runner makes a temporary
CPU build copy that removes the unused GPU backend import/dispatch, because the
local Metal compiler component was unavailable. That exact transformation is in
research/run_blog_benchmark.py. Both CPU algorithms and the rest of the grid stay
unchanged. Compile-time square tables are built before timing; distance-cache
construction and updates are inside the measured interval.

## Run on macOS

From the extracted directory, with uv and FFmpeg available:

    uv venv .venv
    uv pip install --python .venv/bin/python -r requirements.txt --index-strategy unsafe-best-match
    .venv/bin/python research/run_blog_benchmark.py --output research/fresh-results
    .venv/bin/python research/render_blog_video.py --results research/fresh-results --output media

The benchmark needs the full Xcode host developer tools. The renderer uses Pillow
and NumPy (installed through the plotting requirements), system Arial fonts, and
FFmpeg with libx264. It is configured for this macOS environment.

The runner uses 2,000 particles, a 501 x 501 lattice, stickiness 1, and seeds 42-46.
Each algorithm runs separately. Algorithm order and capture-mode order alternate.
Each run starts a new process/grid/cache, following short unmeasured code-path warmups.
No affinity or clock-frequency pinning is applied. Times can vary with scheduling,
power state, and background applications. Both modes retain per-particle timers;
"timing-only" omits event storage, not the timers.

Capture rows are [x, y, cumulative spawn-through-attachment nanoseconds].
The replay uses seed 42 (chosen before measurements), a shared computation clock,
and 2x playback for the recorded run. Each panel freezes at its own finish time.
The fixed view shows coordinates 125 through 375 in both axes, with all recorded
settlements inside it. The renderer asserts this; a new run outside this crop
requires widening BOTH views. The underlying simulation remains 501 x 501.
The speed ratio is the ratio of medians across seeds, not a paired trajectory test.
Different algorithms consume different random numbers; matching pictures are not expected.

Raw JSON recordings and results are included. To render only those results:

    .venv/bin/python research/render_blog_video.py --output media

To rerun measurements, use a fresh output directory; the runner will not overwrite
existing incomplete or different evidence. Matching completed results are reused.

The repository's existing self-checks test square-exit probabilities, distance
updates, boundaries, and partial stickiness. The benchmark also checks particle
counts and the validity of every recorded attachment. Neither the replay nor
similar-looking fractals constitutes a proof of distributional equivalence.
